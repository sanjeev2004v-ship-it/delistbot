"""
24/7 Crypto Delisting Alert Bot - Render Deployment Ready
-----------------------------------
- Monitors top exchanges continuously.
- Sends Telegram alerts instantly when a delisting announcement appears.
- Uses .env file for credentials (safe and easy).

Dependencies:
    pip install requests beautifulsoup4 python-dotenv

.env file example:
TELEGRAM_BOT_TOKEN="123456:ABC-DEF"
TELEGRAM_CHAT_ID="123456789"
"""

import time
import json
import requests
from bs4 import BeautifulSoup
from datetime import datetime
import os
from dotenv import load_dotenv

# Load .env variables
load_dotenv()
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# ---------------- CONFIG -----------------
CHECK_INTERVAL = 60   # seconds
SAVE_FILE = "seen_announcements.json"

KEYWORDS = [
    "delist", "delisting", "remove trading pair", 
    "suspend trading", "terminate trading", "delisted",
]

EXCHANGES = {
    "binance": "https://www.binance.com/en/support/announcement",
    "bybit": "https://announcements.bybit.com/en-US/",
    "kucoin": "https://www.kucoin.com/news",
    "coinbase": "https://www.coinbase.com/blog",
    "kraken": "https://blog.kraken.com/",
    "okx": "https://www.okx.com/learn/announcements",
    "bitget": "https://www.bitget.com/support/announcements",
    "wazirx": "https://wazirx.com/blog/",
    "coindcx": "https://blog.coindcx.com/",
    "mudrex": "https://blog.mudrex.com/",
}

# ------------------------------------------

# Load seen announcements
def load_seen():
    try:
        with open(SAVE_FILE, "r") as f:
            return set(json.load(f))
    except:
        return set()

# Save seen announcements
def save_seen(seen):
    with open(SAVE_FILE, "w") as f:
        json.dump(list(seen), f)

# Telegram alert
def send_telegram(msg):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print("[WARN] Telegram credentials not set!")
        return
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        data = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": msg,
            "parse_mode": "Markdown",
            "disable_web_page_preview": True
        }
        requests.post(url, data=data, timeout=5)
    except Exception as e:
        print("[Error sending Telegram]", e)

# Check if announcement text contains delisting keyword
def contains_keyword(text):
    text = text.lower()
    return any(k in text for k in KEYWORDS)

# Fetch announcements for each exchange (simple HTML scraping)
def fetch_announcements(url):
    try:
        r = requests.get(url, timeout=8)
        soup = BeautifulSoup(r.text, "html.parser")
        links = soup.find_all("a")
        results = []
        for a in links:
            title = (a.text or "").strip()
            href = a.get("href", "")
            if len(title) > 5:
                if href.startswith("/"):
                    href = url.rstrip("/") + href
                results.append({"title": title, "url": href})
        return results
    except Exception as e:
        print("[Fetch error]", url, e)
        return []

# Main loop
def main():
    print("Starting 24/7 Delisting Alert Bot (Render-ready)...")
    seen = load_seen()

    while True:
        try:
            for name, url in EXCHANGES.items():
                print(f"Checking {name}...")
                items = fetch_announcements(url)
                for item in items:
                    unique_id = item['url']
                    if unique_id in seen:
                        continue

                    text = item['title']
                    if contains_keyword(text):
                        timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
                        msg = (
                            f"🚨 *DELISTING ALERT*\n"
                            f"Exchange: {name.upper()}\n"
                            f"Info: {text}\n"
                            f"Link: {item['url']}\n"
                            f"Time (UTC): {timestamp}"
                        )
                        print(msg)
                        send_telegram(msg)

                    seen.add(unique_id)

                save_seen(seen)

        except Exception as e:
            print("[Loop error]", e)

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
